

module.exports = {
	'url': 'mongodb://localhost:27017/resizedb' //mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
};